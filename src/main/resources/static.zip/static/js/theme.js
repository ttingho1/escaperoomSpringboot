lightbox.option({
    resizeDuration: 100,
    wrapAround: true,
    disableScrolling: false,
    fitImagesInViewport:false
});